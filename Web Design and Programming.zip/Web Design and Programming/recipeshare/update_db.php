<?php
// update_db.php - ADDING MISSING COLUMNS
require_once 'db.php';

try {
    // 1. Add a Profile Picture Column (If it doesn't already exist)
    // Error suppression operator (@) or TRY-CATCH to prevent code from crashing if column already exists.
    try {
        $pdo->exec("ALTER TABLE users ADD COLUMN profile_pic VARCHAR(255) DEFAULT NULL");
        echo "<p style='color:green'>✔ The 'profile_pic' column has been added successfully.</p>";
    } catch (PDOException $e) {
        // It will throw an error if the column already exists, but that's okay.
        echo "<p style='color:blue'>ℹ 'profile_pic' sütunu zaten var veya eklenemedi.</p>";
    }

    // 2. Create Image Folder
    if (!file_exists('uploads/avatars')) {
        mkdir('uploads/avatars', 0777, true);
        echo "<p style='color:green'>✔ The image upload folder (uploads/avatars) has been created.</p>";
    }

    // 3. Create the Friend Requests table (if it doesn't already exist).
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS friend_requests (
            id INT AUTO_INCREMENT PRIMARY KEY,
            sender_id INT NOT NULL,
            receiver_id INT NOT NULL,
            status ENUM('pending', 'accepted', 'rejected') DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY unique_request (sender_id, receiver_id)
        )");
        echo "<p style='color:green'>✔ The table 'friend_requests' was successfully created or does not exist.</p>";
    } catch (PDOException $e) {
        echo "<p style='color:blue'>ℹ 'friend_requests' table already exists or could not be created.</p>";
    }

    echo "<h2>✅ UPDATE COMPLETED!</h2>";
    echo "<p>Site should now open without errors.</p>";
    echo "<a href='index.php' style='font-size:20px; font-weight:bold;'>Go Back to Main Page</a>";

} catch (PDOException $e) {
    echo "<h3>Genel Hata:</h3> " . $e->getMessage();
}
?>
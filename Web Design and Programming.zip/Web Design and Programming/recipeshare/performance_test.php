<?php
require_once 'db.php';
$start = microtime(true);

// Simulate a query like in index.php
$sql = "SELECT r.*, u.username FROM recipes r LEFT JOIN users u ON r.user_id = u.id ORDER BY r.created_at DESC LIMIT 10";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$recipes = $stmt->fetchAll();

$end = microtime(true);
$time = ($end - $start) * 1000; // ms

echo "Query execution time: " . round($time, 2) . " ms\n";
echo "Recipes fetched: " . count($recipes) . "\n";
?>
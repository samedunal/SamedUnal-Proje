<?php
include 'header.php';

// Security: Only Admins can access.
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    echo "<div class='text-center py-20 font-bold text-red-600'>Erişim Reddedildi! Sadece yöneticiler girebilir.</div>";
    include 'footer.php'; exit;
}

$msg = "";

// --- STEP 1: DELETING THE EVENT ---
if (isset($_GET['delete_event'])) {
    $eid = (int)$_GET['delete_event'];
    $pdo->prepare("DELETE FROM events WHERE id = ?")->execute([$eid]);
    header("Location: admin.php?msg=Event Deleted"); exit;
}

// --- STEP 2: DELETING THE RECIPE ---
if (isset($_GET['delete_recipe'])) {
    $rid = (int)$_GET['delete_recipe'];
    // Delete related data
    $pdo->prepare("DELETE FROM favorites WHERE recipe_id = ?")->execute([$rid]);
    $pdo->prepare("DELETE FROM ratings WHERE recipe_id = ?")->execute([$rid]);
    $pdo->prepare("DELETE FROM comments WHERE recipe_id = ?")->execute([$rid]);
    $pdo->prepare("DELETE FROM events WHERE recipe_id = ?")->execute([$rid]);
    $pdo->prepare("DELETE FROM recipes WHERE id = ?")->execute([$rid]);
    header("Location: admin.php?msg=Recipe Deleted"); exit;
}

// --- STEP 3: UPDATING THE RECIPE ---
if (isset($_POST['update_recipe'])) {
    $rid = (int)$_POST['recipe_id'];
    $title = clean($_POST['title']);
    $description = clean($_POST['description']);
    $ingredients = clean($_POST['ingredients']);
    $instructions = clean($_POST['instructions']);
    $difficulty = clean($_POST['difficulty']);
    $cuisine = clean($_POST['cuisine']);
    $diet = clean($_POST['diet']);
    $calories = (int)$_POST['calories'];
    $prep_time = (int)$_POST['prep_time'];
    
    $pdo->prepare("UPDATE recipes SET title=?, description=?, ingredients=?, instructions=?, difficulty=?, cuisine=?, diet=?, calories=?, prep_time=? WHERE id=?")->execute([$title, $description, $ingredients, $instructions, $difficulty, $cuisine, $diet, $calories, $prep_time, $rid]);
    $msg = "Recipe successfully updated!";
}

// --- STEP 2: ADDING A NEW EVENT ---
if (isset($_POST['add_event'])) {
    $rid = $_POST['recipe_id'];
    $loc = clean($_POST['location']);
    $date = $_POST['date'];
    $quota = (int)$_POST['quota'];

    $stmt = $pdo->prepare("INSERT INTO events (recipe_id, location, event_date, quota, booked) VALUES (?, ?, ?, ?, 0)");
    $stmt->execute([$rid, $loc, $date, $quota]);
    $msg = "New event successfully created!";
}

// Pull Data
$events = $pdo->query("SELECT e.*, r.title FROM events e JOIN recipes r ON e.recipe_id = r.id ORDER BY e.event_date DESC")->fetchAll();
$recipes = $pdo->query("SELECT id, title FROM recipes ORDER BY title ASC")->fetchAll(); // for Dropdown 
$users = $pdo->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();

// Pull user recipes (excluding admin)
$adminId = $pdo->query("SELECT id FROM users WHERE role='admin' LIMIT 1")->fetchColumn() ?: 1;
$userRecipes = $pdo->query("SELECT r.*, u.username FROM recipes r JOIN users u ON r.user_id = u.id WHERE r.user_id != $adminId ORDER BY r.created_at DESC")->fetchAll();

// The recipe to be edited (if the edit_recipe parameter exists)
$editRecipe = null;
if (isset($_GET['edit_recipe'])) {
    $editId = (int)$_GET['edit_recipe'];
    $editRecipe = $pdo->query("SELECT * FROM recipes WHERE id = $editId")->fetch();
}
?>

<div class="max-w-7xl mx-auto px-4 mt-8 mb-20">
    <h1 class="text-3xl font-bold text-gray-800 mb-8 border-b pb-4"><i class="fas fa-user-shield"></i> Admin Panel</h1>

    <?php if($msg || isset($_GET['msg'])) echo "<div class='bg-green-100 text-green-700 p-4 rounded-xl mb-6 font-bold'>".($msg ?: $_GET['msg'])."</div>"; ?>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-10">
        
        <div>
            <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 mb-8">
                <h2 class="text-xl font-bold text-purple-700 mb-4"><i class="fas fa-plus-circle"></i> Add New Event</h2>
                
                <form method="post" class="space-y-4">
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">Select Recipe</label>
                        <select name="recipe_id" class="w-full border p-2 rounded-lg" required>
                            <?php foreach($recipes as $r): ?>
                                <option value="<?php echo $r['id']; ?>"><?php echo htmlspecialchars($r['title']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">Location</label>
                        <input type="text" name="location" placeholder="For example: Lezzet Atölyesi, Taksim" class="w-full border p-2 rounded-lg" required>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-1">Date</label>
                            <input type="date" name="date" class="w-full border p-2 rounded-lg" required>
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-1">Quota</label>
                            <input type="number" name="quota" value="10" class="w-full border p-2 rounded-lg" required>
                        </div>
                    </div>

                    <button name="add_event" class="w-full bg-purple-600 text-white py-2 rounded-lg font-bold hover:bg-purple-700 transition">Publish Event</button>
                </form>
            </div>

            <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Active Events</h2>
                <div class="space-y-3">
                    <?php foreach($events as $e): ?>
                        <div class="flex justify-between items-center bg-gray-50 p-3 rounded-lg border border-gray-200">
                            <div>
                                <h4 class="font-bold text-gray-800 text-sm"><?php echo htmlspecialchars($e['title']); ?></h4>
                                <p class="text-xs text-gray-500">
                                    <i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($e['location']); ?> | 
                                    <i class="far fa-calendar"></i> <?php echo $e['event_date']; ?>
                                </p>
                                <p class="text-xs font-bold text-green-600">Fullness: <?php echo $e['booked']; ?> / <?php echo $e['quota']; ?></p>
                            </div>
                            <a href="admin.php?delete_event=<?php echo $e['id']; ?>" onclick="return confirm('Are you sure you want to delete this activity?')" class="bg-red-100 text-red-600 px-3 py-1 rounded hover:bg-red-200 text-sm">
                                <i class="fas fa-trash"></i> Delete
                            </a>
                        </div>
                    <?php endforeach; ?>
                    <?php if(count($events)==0) echo "<p class='text-gray-400 text-sm'>No events yet.</p>"; ?>
                </div>
            </div>
        </div>

        <div>
            <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 mb-8">
                <h2 class="text-xl font-bold text-gray-800 mb-4"><i class="fas fa-users"></i> Registered Users</h2>
                <div class="overflow-auto max-h-[400px]">
                    <table class="w-full text-sm text-left">
                        <thead class="bg-gray-100 text-gray-600 font-bold">
                            <tr>
                                <th class="p-3">ID</th>
                                <th class="p-3">Username</th>
                                <th class="p-3">Email</th>
                                <th class="p-3">Rol</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y">
                            <?php foreach($users as $u): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="p-3"><?php echo $u['id']; ?></td>
                                <td class="p-3 font-bold"><?php echo htmlspecialchars($u['username']); ?></td>
                                <td class="p-3 text-gray-500"><?php echo htmlspecialchars($u['email']); ?></td>
                                <td class="p-3">
                                    <span class="px-2 py-1 rounded text-xs font-bold <?php echo $u['role']=='admin'?'bg-red-100 text-red-700':'bg-blue-100 text-blue-700'; ?>">
                                        <?php echo strtoupper($u['role']); ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                <h2 class="text-xl font-bold text-gray-800 mb-4"><i class="fas fa-utensils"></i> User Recipes</h2>
                <div class="overflow-auto max-h-[600px]">
                    <?php if(count($userRecipes) > 0): ?>
                        <div class="space-y-3">
                            <?php foreach($userRecipes as $ur): ?>
                                <div class="flex justify-between items-start bg-gray-50 p-4 rounded-lg border border-gray-200">
                                    <div class="flex-1">
                                        <div class="flex items-center gap-3 mb-2">
                                            <img src="<?php echo img_src($ur['image']); ?>" class="w-16 h-16 object-cover rounded-lg">
                                            <div>
                                                <h4 class="font-bold text-gray-800 text-sm"><?php echo htmlspecialchars($ur['title']); ?></h4>
                                                <p class="text-xs text-gray-500">by <?php echo htmlspecialchars($ur['username']); ?></p>
                                                <p class="text-xs text-gray-400 mt-1"><?php echo date('M d, Y', strtotime($ur['created_at'])); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flex gap-2">
                                        <a href="admin.php?edit_recipe=<?php echo $ur['id']; ?>" class="bg-blue-100 text-blue-600 px-3 py-1 rounded hover:bg-blue-200 text-sm">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>
                                        <a href="admin.php?delete_recipe=<?php echo $ur['id']; ?>" onclick="return confirm('Are you sure you want to delete this recipe?')" class="bg-red-100 text-red-600 px-3 py-1 rounded hover:bg-red-200 text-sm">
                                            <i class="fas fa-trash"></i> Delete
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-gray-400 text-sm text-center py-8">No user description yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>

    <?php if($editRecipe): ?>
    <!-- Editing Modal -->
    <div class="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 mt-8">
        <div class="bg-white p-6 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl">
            <div class="flex justify-between items-center mb-4">
                <h3 class="font-bold text-xl text-gray-800">Edit Recipe</h3>
                <a href="admin.php" class="text-gray-500 hover:text-gray-700"><i class="fas fa-times"></i></a>
            </div>
            <form method="post" class="space-y-4">
                <input type="hidden" name="recipe_id" value="<?php echo $editRecipe['id']; ?>">
                
                <div>
                    <label class="block text-sm font-bold text-gray-700 mb-1">Title</label>
                    <input type="text" name="title" value="<?php echo htmlspecialchars($editRecipe['title']); ?>" class="w-full border p-2 rounded-lg" required>
                </div>
                
                <div>
                    <label class="block text-sm font-bold text-gray-700 mb-1">Description</label>
                    <textarea name="description" rows="3" class="w-full border p-2 rounded-lg" required><?php echo htmlspecialchars($editRecipe['description']); ?></textarea>
                </div>
                
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">Difficulty</label>
                        <select name="difficulty" class="w-full border p-2 rounded-lg" required>
                            <option value="Easy" <?php echo $editRecipe['difficulty']=='Easy'?'selected':''; ?>>Easy</option>
                            <option value="Medium" <?php echo $editRecipe['difficulty']=='Medium'?'selected':''; ?>>Medium</option>
                            <option value="Hard" <?php echo $editRecipe['difficulty']=='Hard'?'selected':''; ?>>Hard</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">Cuisine</label>
                        <input type="text" name="cuisine" value="<?php echo htmlspecialchars($editRecipe['cuisine']); ?>" class="w-full border p-2 rounded-lg" required>
                    </div>
                </div>
                
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">Diet</label>
                        <input type="text" name="diet" value="<?php echo htmlspecialchars($editRecipe['diet']); ?>" class="w-full border p-2 rounded-lg" required>
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">Calories</label>
                        <input type="number" name="calories" value="<?php echo $editRecipe['calories']; ?>" class="w-full border p-2 rounded-lg" required>
                    </div>
                </div>
                
                <div>
                    <label class="block text-sm font-bold text-gray-700 mb-1">Preparation Time (minutes)</label>
                    <input type="number" name="prep_time" value="<?php echo $editRecipe['prep_time']; ?>" class="w-full border p-2 rounded-lg" required>
                </div>
                
                <div>
                    <label class="block text-sm font-bold text-gray-700 mb-1">Ingredients (comma separated)</label>
                    <textarea name="ingredients" rows="4" class="w-full border p-2 rounded-lg" required><?php echo htmlspecialchars($editRecipe['ingredients']); ?></textarea>
                </div>
                
                <div>
                    <label class="block text-sm font-bold text-gray-700 mb-1">Instructions</label>
                    <textarea name="instructions" rows="6" class="w-full border p-2 rounded-lg" required><?php echo htmlspecialchars($editRecipe['instructions']); ?></textarea>
                </div>
                
                <div class="flex gap-2">
                    <button type="submit" name="update_recipe" class="flex-1 bg-green-600 text-white py-2 rounded-lg font-bold hover:bg-green-700 transition">Update</button>
                    <a href="admin.php" class="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg font-bold hover:bg-gray-300 transition text-center">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php include 'footer.php'; ?>
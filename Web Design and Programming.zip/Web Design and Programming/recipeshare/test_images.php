<?php
// test_images.php - Image File Path and Name Checker Tool
require_once 'db.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<!DOCTYPE html><html><head><title>Image Issue Analysis</title>";
echo "<style>body{font-family:sans-serif; padding:20px;} .success{color:green;} .error{color:red; font-weight:bold;} .info{color:blue;} .box{border:1px solid #ccc; padding:15px; margin-top:15px; border-radius:8px;}</style>";
echo "</head><body>";
echo "<h2>🖼️ Image Issue Analysis</h2>";

$uploads_dir = 'uploads';

// 1. UPLOAD FOLDER'S EXISTENCE
if (!is_dir($uploads_dir)) {
    echo "<p class='error'>❌ ERROR: '$uploads_dir' folder not found!</p>";
    echo "<p>Please create this folder: <code>C:\\xampp\\htdocs\\recipeshare\\uploads</code></p>";
    exit;
} else {
    echo "<p class='success'>✅ '$uploads_dir' folder exists.</p>";
}

//2. REMOVE THE ACTUAL FILES FROM THE FOLDER.
$files_in_dir = glob($uploads_dir . '/*.jpg');
$real_file_names = [];
foreach ($files_in_dir as $file) {
    // Get filename only
    $real_file_names[] = basename($file); 
}

// 3. RETRIEVES THE EXPECTED NAMES FROM THE DATABASE.
$expected_images = $pdo->query("SELECT title, image FROM recipes LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);

echo "<div class='box'><h3>📂The actual files in the folder (" . count($real_file_names) . " adet)</h3>";
$i=0;
foreach($real_file_names as $name) {
    echo "- " . htmlspecialchars($name) . "<br>";
    if ($i++ > 10) { echo "... (Devamı var)"; break; }
}
echo "</div>";


echo "<div class='box'><h3>🗄️ Names in the Database (Example from the Top 100 Recipes)</h3>";
$total_missing = 0;
foreach ($expected_images as $recipe) {
    $expected_name = htmlspecialchars($recipe['image']);
    $title = htmlspecialchars($recipe['title']);
    
    // Exact match check with names in the folder (including case control)
    if (in_array($expected_name, $real_file_names)) {
        // If there is an exact match
        echo "<p class='success'>✅FOUND! - Recipe: $title | Beklenti: <code>$expected_name</code></p>";
    } else {
        // If there is no exact match, check if the file exists case-wise (a common error in Windows).
        $found_case_insensitive = false;
        foreach($real_file_names as $real_name) {
            if (strtolower($real_name) == strtolower($expected_name)) {
                echo "<p class='error'>❌ NOT FOUND! (Case Difference) - Recipe: $title | Expected: <code>$expected_name</code> | Actual: <code>$real_name</code></p>";
                $found_case_insensitive = true;
                break;
            }
        }

        if (!$found_case_insensitive) {
            // If it could not be found at all 
            echo "<p class='error'>❌ NOT FOUND! - Recipe: $title | Expected: <code>$expected_name</code></p>";
            echo "<p class='info' style='margin-left:20px;'>Reason: There is no file named <code>$expected_name</code> in the '$uploads_dir' folder.</p>";
        }
        $total_missing++;
    }
}
echo "</div>";

if ($total_missing > 0) {
    echo "<h3 class='error'>⚠️ Summary: $total_missing images not found.</h3>";
    echo "<p>Please rename the image files in the 'uploads' folder to match the format expected by the database: <code>image_XXXX.jpg</code>.</p>";
} else {
    echo "<h3 class='success'>🎉 Summary: All images found! Site should work without issues.</h3>";
}

echo "</body></html>";
?>
<?php
// setup.php - TABLE CONFIGURATION ONLY
require_once 'db.php'; // Bağlantı ve database seçimi zaten burada yapılıyor

try {
    // Since the PDO object comes from db.php, we skip directly to the queries.
    // It only checks the tables, 
    
    $tables = [
        "users" => "CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50), email VARCHAR(100), password VARCHAR(255), role ENUM('user','admin') DEFAULT 'user', profile_pic VARCHAR(255), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",
        "recipes" => "CREATE TABLE IF NOT EXISTS recipes (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT, title VARCHAR(150), description TEXT, ingredients TEXT, instructions TEXT, image VARCHAR(255), difficulty VARCHAR(20), cuisine VARCHAR(50), diet VARCHAR(50), calories INT, prep_time INT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",
        "ratings" => "CREATE TABLE IF NOT EXISTS ratings (user_id INT, recipe_id INT, rating TINYINT, PRIMARY KEY (user_id, recipe_id))",
        "friend_requests" => "CREATE TABLE IF NOT EXISTS friend_requests (id INT AUTO_INCREMENT PRIMARY KEY, sender_id INT NOT NULL, receiver_id INT NOT NULL, status ENUM('pending','accepted','rejected') DEFAULT 'pending', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",
        "recommendations" => "CREATE TABLE IF NOT EXISTS recommendations (id INT AUTO_INCREMENT PRIMARY KEY, sender_id INT NOT NULL, receiver_id INT NOT NULL, recipe_id INT NOT NULL, message TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)"
    ];

    foreach ($tables as $name => $sql) {
        $pdo->exec($sql);
    }

    echo "<h2 style='color:green'>✅Table checks completed successfully.!</h2>";
    echo "<a href='index.php'>Return to Home Page</a>";

} catch (PDOException $e) {
    echo "<h3 style='color:red'>Connection Error:</h3> " . $e->getMessage();
}
?>
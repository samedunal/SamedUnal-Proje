\</main>
<footer class="bg-white border-t mt-12 py-8 text-center text-gray-500 text-sm w-full">
    <p>&copy; <?php echo date('Y'); ?> RecipeShare. All rights reserved.</p>
</footer>

<!-- Dark Mode Toggle Button -->
<button id="themeToggle" class="theme-toggle" onclick="toggleTheme()" title="Toggle Dark Mode">
    <i class="fas fa-moon" id="themeIcon"></i>
</button>

<script>
// Dark Mode Toggle
function toggleTheme() {
    const body = document.body;
    const icon = document.getElementById('themeIcon');
    
    if (body.classList.contains('dark-mode')) {
        body.classList.remove('dark-mode');
        icon.classList.remove('fa-sun');
        icon.classList.add('fa-moon');
        localStorage.setItem('theme', 'light');
    } else {
        body.classList.add('dark-mode');
        icon.classList.remove('fa-moon');
        icon.classList.add('fa-sun');
        localStorage.setItem('theme', 'dark');
    }
}

// Load saved theme
document.addEventListener('DOMContentLoaded', function() {
    const savedTheme = localStorage.getItem('theme');
    const icon = document.getElementById('themeIcon');
    
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-mode');
        icon.classList.remove('fa-moon');
        icon.classList.add('fa-sun');
    }
});
</script>
</body>
</html>
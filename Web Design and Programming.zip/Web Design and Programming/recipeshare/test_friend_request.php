<?php
require_once 'db.php';
try {
    // Test insert
    $pdo->prepare("INSERT INTO friend_requests (sender_id, receiver_id) VALUES (?, ?)")->execute([1, 2]);
    echo "Inserted test friend request.\n";

    $count = $pdo->query("SELECT COUNT(*) FROM friend_requests")->fetchColumn();
    echo "friend_requests count: $count\n";

    // Clean up the inserted test row
    $pdo->prepare("DELETE FROM friend_requests WHERE sender_id = ? AND receiver_id = ? LIMIT 1")->execute([1,2]);
    echo "Cleaned up test row.\n";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
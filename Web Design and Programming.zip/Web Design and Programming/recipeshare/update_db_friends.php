<?php
// update_db_friends.php - Friend Requests Table
require_once 'db.php';

try {
    // Friend requests tablosunu oluştur
    $pdo->exec("CREATE TABLE IF NOT EXISTS friend_requests (
        id INT AUTO_INCREMENT PRIMARY KEY,
        sender_id INT NOT NULL,
        receiver_id INT NOT NULL,
        status ENUM('pending', 'accepted', 'rejected') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY unique_request (sender_id, receiver_id)
    )");
    
    echo "<h2 style='color:green'>✅ Friend Requests tablosu oluşturuldu!</h2>";
    echo "<a href='index.php'>Ana Sayfaya Dön</a>";
} catch (PDOException $e) {
    echo "Hata: " . $e->getMessage();
}
?>


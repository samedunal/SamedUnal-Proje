<?php
// insert_events.php - DEFAULT EVENT LOADER
require_once 'db.php';

try {
    // Let's clear up the existing activities first (to avoid conflicts).
    $pdo->exec("DELETE FROM events");

    // Draw 3 random recipe IDs.
    $recipes = $pdo->query("SELECT id FROM recipes ORDER BY RAND() LIMIT 3")->fetchAll(PDO::FETCH_COLUMN);

    if (count($recipes) < 3) {
        die("<h3 style='color:red'>HATA: Önce sisteme en az 3 yemek tarifi eklemelisiniz! (import_csv.php çalıştırın)</h3>");
    }

    // Example Places
    $locations = [
        "Gastronomi Atölyesi - Taksim",
        "Boğaz Manzaralı Teras - Ortaköy",
        "Şefin Gizli Mutfağı - Kadıköy"
    ];

    $sql = "INSERT INTO events (recipe_id, event_date, quota, booked, location) VALUES (?, CURDATE() + INTERVAL ? DAY, 3, ?, ?)";
    $stmt = $pdo->prepare($sql);

    // 1. EVENT
    $stmt->execute([$recipes[0], 0, rand(0, 5), $locations[0]]);
    
    // 2. EVENT
    $stmt->execute([$recipes[1], 0, rand(2, 3), $locations[1]]);
    
    // 3. EVENT
    $stmt->execute([$recipes[2], 0, 6, $locations[2]]);

    echo "<h2 style='color:green'>✅ 3 Default Events Added!</h2>";
    echo "<p>You can now see them on the 'Events' page.</p>";
    echo "<a href='events.php'>View Events</a> | <a href='admin.php'>Go to Admin Panel</a>";

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database credentials
$host = 'localhost';
$dbname = 'recipeshare';
$username = 'root';
$password = '';

try {
    // Create new PDO connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    
    // Set error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Set default fetch mode to associative array
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    // Stop execution on connection error
    die("Connection Error: " . $e->getMessage());
}

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Check if user has admin role
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Sanitize input data
function clean($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Image helper: returns a usable src URL. If image file doesn't exist or is empty, returns an inline SVG placeholder data URI.
function img_src($path, $w = 800, $h = 600) {
    // Simple SVG placeholder
    $svg = "<svg xmlns='http://www.w3.org/2000/svg' width='$w' height='$h'>"
         . "<rect fill='%23f8faf9' width='100%' height='100%'/><text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' font-family='Arial, Helvetica, sans-serif' font-size='20' fill='%239ca3af'>No image</text></svg>";
    $data = 'data:image/svg+xml;utf8,' . rawurlencode($svg);

    if (!$path) return $data;

    // If path already starts with uploads/, use directly
    if (strpos($path, 'uploads/') === 0) {
        $full = __DIR__ . '/' . $path;
        if (file_exists($full) && filesize($full) > 0) return $path;
        return $data;
    }

    // Otherwise try uploads/<path>
    $full = __DIR__ . '/uploads/' . $path;
    if (file_exists($full) && filesize($full) > 0) return 'uploads/' . $path;

    return $data;
}
?>
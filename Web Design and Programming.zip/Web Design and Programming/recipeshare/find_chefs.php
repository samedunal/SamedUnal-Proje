<?php
include 'header.php';
if (!isLoggedIn()) {
    header("Location: login.php");
    exit;
}

$uid = $_SESSION['user_id'];
$search = $_GET['q'] ?? '';
$message = '';

// Ensure friend_requests table exists; if missing, create it and reload
try {
    $pdo->query("SELECT 1 FROM friend_requests LIMIT 1");
} catch (PDOException $e) {
    if ($e->getCode() === '42S02') {
        // No table - create
        $pdo->exec("CREATE TABLE IF NOT EXISTS friend_requests (
            id INT AUTO_INCREMENT PRIMARY KEY,
            sender_id INT NOT NULL,
            receiver_id INT NOT NULL,
            status ENUM('pending','accepted','rejected') DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY unique_request (sender_id, receiver_id)
        )");
        // We will redirect the process and try again in a clean manner.
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    } else {
        throw $e;
    }
}

// --- FRIEND REQUEST PROCEDURES ---
if (isset($_GET['action']) && isset($_GET['chef_id'])) {
    $chef_id = (int)$_GET['chef_id'];
    
    // Prevent adding yourself as a friend.
    if ($chef_id == $uid) {
        $message = "<div class='text-red-600 font-bold'>Kendinizi arkadaş olarak ekleyemezsiniz.</div>";
    } else {
        if ($_GET['action'] == 'follow') {
            //Send a friend request (add to the friend_requests table)
            // Check first - has a request already been sent?
            $checkRequest = $pdo->prepare("SELECT * FROM friend_requests WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)");
            $checkRequest->execute([$uid, $chef_id, $chef_id, $uid]);
            
            if ($checkRequest->rowCount() == 0) {
                //Send new friend request
                $pdo->prepare("INSERT INTO friend_requests (sender_id, receiver_id, status) VALUES (?, ?, 'pending')")->execute([$uid, $chef_id]);
                $message = "<div class='text-green-600 font-bold'>Arkadaş isteği gönderildi!</div>";
            } else {
                $message = "<div class='text-yellow-600 font-bold'>Zaten bir arkadaş isteği mevcut.</div>";
            }
        } elseif ($_GET['action'] == 'accept') {
            // Accept friend request
            $pdo->prepare("UPDATE friend_requests SET status = 'accepted' WHERE sender_id = ? AND receiver_id = ?")->execute([$chef_id, $uid]);
            // Add mutual friends
            $pdo->prepare("INSERT IGNORE INTO follows (follower_id, followed_id) VALUES (?, ?)")->execute([$uid, $chef_id]);
            $pdo->prepare("INSERT IGNORE INTO follows (follower_id, followed_id) VALUES (?, ?)")->execute([$chef_id, $uid]);
            $message = "<div class='text-green-600 font-bold'>Arkadaş isteği kabul edildi!</div>";
        } elseif ($_GET['action'] == 'unfollow') {
            // unfriend
            $pdo->prepare("DELETE FROM follows WHERE (follower_id = ? AND followed_id = ?) OR (follower_id = ? AND followed_id = ?)")->execute([$uid, $chef_id, $chef_id, $uid]);
            $pdo->prepare("DELETE FROM friend_requests WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)")->execute([$uid, $chef_id, $chef_id, $uid]);
            $message = "<div class='text-orange-600 font-bold'>Arkadaşlık kaldırıldı.</div>";
        }
        // Clear the URL and keep the message.
        header("Location: find_chefs.php?q=" . urlencode($search) . "&msg=" . urlencode($message));
        exit;
    }
}

// URL'den mesaj çekme
if (isset($_GET['msg'])) {
    $message = $_GET['msg'];
}

// ---  USER SEARCH QUERY ---
$sql = "SELECT id, username, profile_pic FROM users WHERE role = 'user' AND id != ?";
$params = [$uid];

if ($search) {
    $sql .= " AND username LIKE ?";
    $params[] = "%$search%";
}

// Retrieve the IDs of users who are friends (mutually)
$friends = $pdo->query("SELECT followed_id FROM follows WHERE follower_id = $uid 
                        UNION 
                        SELECT follower_id FROM follows WHERE followed_id = $uid")->fetchAll(PDO::FETCH_COLUMN);

// Pending friend requests
$pendingSent = $pdo->query("SELECT receiver_id FROM friend_requests WHERE sender_id = $uid AND status = 'pending'")->fetchAll(PDO::FETCH_COLUMN);
$pendingReceived = $pdo->query("SELECT sender_id FROM friend_requests WHERE receiver_id = $uid AND status = 'pending'")->fetchAll(PDO::FETCH_COLUMN);

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$chefs = $stmt->fetchAll();
?>

<div class="max-w-4xl mx-auto mt-10 px-6 mb-20">
    <h1 class="text-3xl font-bold text-gray-900 mb-6 flex items-center gap-2">
        <i class="fas fa-users text-orange-600"></i> Find Friends
    </h1>

    <?php if ($message): ?>
        <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-4 rounded-lg">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 mb-8">
        <form method="GET" class="flex gap-4">
            <input type="text" name="q" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search by username..." 
                   class="flex-1 border border-gray-300 p-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 transition" required>
            <button type="submit" class="bg-orange-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-orange-700 transition">
                <i class="fas fa-search"></i> Search
            </button>
            <?php if ($search): ?>
                <a href="find_chefs.php" class="bg-gray-200 text-gray-600 px-6 py-3 rounded-xl font-bold hover:bg-gray-300 transition">Clear</a>
            <?php endif; ?>
        </form>
    </div>

    <?php if ($search && count($chefs) > 0): ?>
        <h2 class="text-xl font-bold mb-4 text-gray-800"><?php echo count($chefs); ?> Users Found:</h2>
        <div class="space-y-4">
            <?php foreach ($chefs as $chef): ?>
                <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex justify-between items-center transition hover:shadow-md">
                    <div class="flex items-center gap-4">
                        <?php if($chef['profile_pic'] && file_exists($chef['profile_pic'])): ?>
                            <img src="<?php echo htmlspecialchars($chef['profile_pic']); ?>" class="w-12 h-12 rounded-full object-cover border-2 border-orange-200">
                        <?php else: ?>
                            <div class="w-12 h-12 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center text-xl font-bold">
                                <?php echo strtoupper(substr($chef['username'], 0, 1)); ?>
                            </div>
                        <?php endif; ?>

                        <div>
                            <span class="font-bold text-lg text-gray-900"><?php echo htmlspecialchars($chef['username']); ?></span>
                        </div>
                    </div>
                    
                    <?php 
                        $isFriend = in_array($chef['id'], $friends);
                        $hasPendingSent = in_array($chef['id'], $pendingSent);
                        $hasPendingReceived = in_array($chef['id'], $pendingReceived);
                        
                        if ($isFriend) {
                            $action = 'unfollow';
                            $buttonText = 'Friends';
                            $buttonClass = 'bg-blue-200 text-blue-700 hover:bg-blue-300';
                        } elseif ($hasPendingSent) {
                            $action = '';
                            $buttonText = 'Request Sent';
                            $buttonClass = 'bg-yellow-200 text-yellow-700 cursor-not-allowed';
                        } elseif ($hasPendingReceived) {
                            $action = 'accept';
                            $buttonText = 'Accept';
                            $buttonClass = 'bg-green-600 text-white hover:bg-green-700';
                        } else {
                            $action = 'follow';
                            $buttonText = '+ Add Friend';
                            $buttonClass = 'bg-green-600 text-white hover:bg-green-700';
                        }
                    ?>
                    <?php if ($action): ?>
                    <a href="find_chefs.php?action=<?php echo $action; ?>&chef_id=<?php echo $chef['id']; ?>&q=<?php echo urlencode($search); ?>" 
                       class="px-6 py-2 rounded-full font-bold text-sm transition <?php echo $buttonClass; ?>">
                        <?php echo $buttonText; ?>
                    </a>
                    <?php else: ?>
                    <span class="px-6 py-2 rounded-full font-bold text-sm <?php echo $buttonClass; ?>">
                        <?php echo $buttonText; ?>
                    </span>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php elseif ($search): ?>
        <div class="text-center py-20 bg-gray-50 rounded-xl border border-dashed border-gray-300">
            <i class="fas fa-search text-4xl text-gray-400 mb-3"></i>
            <p class="text-gray-600 font-medium">No users found matching "<?php echo htmlspecialchars($search); ?>".</p>
        </div>
    <?php else: ?>
        <div class="text-center py-20 bg-gray-50 rounded-xl border border-dashed border-gray-300">
            <i class="fas fa-search text-4xl text-gray-400 mb-3"></i>
            <p class="text-gray-600 font-medium">Start searching to find new friends!</p>
        </div>
    <?php endif; ?>

</div>
<?php include 'footer.php'; ?>